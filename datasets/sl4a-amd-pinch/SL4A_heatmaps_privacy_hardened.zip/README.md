# Surface Laptop 4 AMD — capacitive heatmap pinch research dataset

This is a PRIVACY-HARDENED derivative of a voluntarily performed touchscreen
pinch experiment. It is designed for offline research, not to be fed back to
a physical device. Publication is at the data owner's discretion.

## What is included
- `heatmaps_u8.bin`: 8,232 frames, exactly 3,456 bytes each (48 rows by 72
  columns, unsigned 8-bit values, contiguous, in sensor capture order).
  Byte 180 is a common background value in this run; lower values may
  represent stronger candidate touch signal. No special image codec.
- `frame_relative_ticks.csv`: one tick timestamp per frame, relative to the
  first sensor frame; tick frequency appears close to 10 MHz. Timing is
  uncalibrated against the OS pointer clock. Gaps have been retained.
- `os_contact_transitions_relative.csv`: seven pseudonymous OS contact
  lifetimes (DOWN/UP) and three operator annotations when two physical
  fingers were present but only one app-level contact was observed.
  Times are relative to the first OS pointer DOWN, **not automatically
  synchronized** to the relative sensor ticks.
- `metadata.json`: decoding details and SHA-256 of the raster-only bytes.

These are **capacitive intensity maps**, not photos or conventional
fingerprints. This does not guarantee that a distinctive physical touch
pattern or device baseline could never be associated with other data.

## How to inspect

With NumPy installed, load a single 48 x 72 frame:

    import numpy as np
    values = np.fromfile('heatmaps_u8.bin', dtype=np.uint8)
    frames = values.reshape(8232, 48, 72)
    frame = frames[2000]  # one 48-row, 72-column matrix

Use `frame_relative_ticks.csv` for frame cadence and event annotations for
contact lifecycle. Do NOT assume raw and OS clocks are synchronized at
the first frames. Each row of the raster is one sensor row, not a screen
pixel in an application screenshot.

## Privacy and limits

Original ETL/CSV, vendor payload sections, absolute capture date and time,
raw Windows contact IDs, source trace hashes, account links, username,
paths, OS screen coordinates and host metadata were intentionally removed.
ZIP member timestamps are neutralized. No automatic upload was performed.

Simple connected-components may merge two physically close fingers into one
region. These frames do not include Windows classifier internals and cannot
by themselves assign root cause to hardware, firmware or software.
No software license or sharing permission is granted by packaging this data.
